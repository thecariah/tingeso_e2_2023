package cl.tingeso.estudianteservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudianteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
