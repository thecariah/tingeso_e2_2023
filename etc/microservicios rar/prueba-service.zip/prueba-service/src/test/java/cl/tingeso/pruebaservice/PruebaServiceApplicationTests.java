package cl.tingeso.pruebaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
